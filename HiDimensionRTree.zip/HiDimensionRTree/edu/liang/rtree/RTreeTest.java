/* ----------------------------------------------------------------------------
    Author: Liang Tang
    Email:  liang@auburn.edu
    Date:   Sept, 2013
    Decrption: High dimensional R-Tree library for research use only
	---------------------------------------------------------------------------- */
package edu.liang.rtree;
import org.junit.* ;
import org.junit.Assert.* ;


public class RTreeTest {

   @Test
   public void test_returnEuro() {
      System.out.println("Test if pricePerMonth returns Euro...") ;
      RTree<Double> rtree = new RTree<Double>(2);
   }
}
